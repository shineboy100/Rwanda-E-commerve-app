from django.contrib import admin
from .models import Appointment
# Register your models here.

admin.site.register(Appointment)
